//
// Created by kirill on 11.11.16.
//

#include "RiverProblem.h"

int main()
{
    RiverProblem riverProblem;
    riverProblem.read();
    riverProblem.calculate();
    riverProblem.write();
    return 0;
}

// EOF
